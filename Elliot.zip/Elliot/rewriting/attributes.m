declare  attributes GrpMat: X, XSLP, CB, Module, PG1, PG2, PG3;

