import "symplectic.m": SymplecticCBM;
import "standard.m": SpChosenElements;
import "MatrixPGroup.m": MatrixPGroupWordInGen;

/* BB is an element of GF(q). This algorithm returns the
   transvection with BB in the [2, 1] position */

GetBBTransvection := function(BB, SLP)

   F := Parent(BB);
   e := Degree(F);
   Z := IntegerRing();
   w := PrimitiveElement(F);

   FF := sub<F|w^2>;
   // FF.1 = (F.1)^2; <- this will be true
   py := FF!F.1;

   // O := Id(G);
   OO := Id(SLP);
   for i in [1..e] do
      // O := O*(t^delta^-(i-1))^Z!Eltseq(py)[i];
      OO := OO*(SLP.3^SLP.1^-(i-1))^Z!Eltseq(py)[i];
   end for;

   // T := t^-1;
   TT := SLP.3^-1;
   // T := (T^s)^Z!Eltseq(BB)[1];
   TT := (TT^SLP.2)^Z!Eltseq(BB)[1];

   for r in [2..e] do
      if IsEven(r) then
         // o := O^-1;
         oo := OO^-1;
         // o := o^(delta^-Z!((r-2)/2));
         oo := oo^(SLP.1^-Z!((r-2)/2));
         // o := (o^s)^Z!Eltseq(BB)[r];
         oo := (oo^SLP.2)^Z!Eltseq(BB)[r];
         // T := T*o;
         TT := TT*oo;
      else
         // o := t^-1;
         oo := SLP.3^-1;
         // o := o^(delta^-Z!((r-1)/2));
         oo := oo^(SLP.1^-Z!((r-1)/2));
         // o := (o^s)^Z!Eltseq(BB)[r];
         oo := (oo^SLP.2)^Z!Eltseq(BB)[r];
         // T := T*o;
         TT := TT*oo;
      end if;
   end for;

   return TT;

end function;

/* This function gets a 1 in the [1, 1] position of A. 
   S1 and S2 are SLPs. */

GetAOne := procedure(~A, ~S1, ~S2)

   SLP := Parent(S1);
   F := BaseRing(A);
   w := PrimitiveElement(F);
   d := Nrows(A);
   Z := IntegerRing();

   if A[1, 1] ne 1 then
      i := 2;
      while A[1, i] eq 0 do
         i := i+1;
         if i eq d+1 then break; end if;
      end while;

      if i eq d+1 then
         // A := A*t;
         AddColumn(~A, 1, 1, 2);
         S2 := S2*SLP.3;
         i := 2;
      end if;
   
      if i eq 2 then
      /* here we add the necessary multiple of column 2
         to column 1 to make A[1, 1] = 1 */

         BB := (1-A[1, 1])/A[1, 2];
         TT := GetBBTransvection(BB, SLP);
         AddColumn(~A, BB, 2, 1);
         // A := A*T;
         S2 := S2*TT;

      else
         /* the case where A[1, 2] = 0 */
         /* we move the non-zero entry to position 4 */
         BB := (1-A[1, 1])/A[1, i];
         TT := GetBBTransvection(BB, SLP);

         /* deciding which block the non-zero entry is in */
         if IsEven(i) then j := i div 2;
         else j := Z!(i/2 + 1/2); end if;

         /* we get the non-zero entry into the second block*/
         if j eq 2 then
            A := A;
         else
            /* A := A*(u*v^-1)^(j-2)*(u*v)^(j-2)*(u*v^-1)^(j-2)*(u*v)^(j-2)*u;
	       swaps block 2 with block j to get the block
               with the non-zero entry as the second block of A
            */
            SwapColumns(~A, 3, 2*j - 1);
            SwapColumns(~A, 4, 2*j);
            S2 := S2*(SLP.4*SLP.5^-1)^(j-2)*(SLP.4*SLP.5)^(j-2)
                  *(SLP.4*SLP.5^-1)^(j-2)*(SLP.4*SLP.5)^(j-2)*SLP.4;
         end if;

         /* A := A*s;
            puts the entry you wish to make equal to 1 in A[1, 2] */
         MultiplyColumn(~A, -1, 1);
         SwapColumns(~A, 1, 2);
         S2 := S2*SLP.2;
         /* A := A*u;
            puts the entry you wish to make equal to 1 in A[1, 4]
         */
         SwapColumns(~A, 1, 3);
         SwapColumns(~A, 2, 4);
         S2 := S2 * SLP.4;
      
         /* we now add column 4 to 1 and column 2 to 3 in order that,
            when we stick all the columns back again, there will be a
            non-zero entry in the A[1, 2] position
         */
         if IsEven(i) then 
            // A := A*x;
            AddColumn(~A, 1, 4, 1);
            AddColumn(~A, 1, 2, 3);
            S2 := S2*SLP.6;
         else
            // A := A*s*x*(s^-1);
            MultiplyColumn(~A, -1, 1); // s
            SwapColumns(~A, 1, 2); // s
            AddColumn(~A, 1, 4, 1); // x
            AddColumn(~A, 1, 2, 3); // x
            SwapColumns(~A, 1, 2); // s^-1
            MultiplyColumn(~A, -1, 1); // s^-1
            S2 := S2*SLP.2*SLP.6*(SLP.2 ^-1);
         end if;
      
         /* we now proceed to stick all the columns back again */
         // A := A*(u^-1);
         SwapColumns(~A, 1, 3);
         SwapColumns(~A, 2, 4);
         S2 := S2*(SLP.4 ^-1);
         // A := A*(s^-1);
         SwapColumns(~A, 1, 2); // s^-1
         MultiplyColumn(~A, -1, 1); // s^-1
         S2 := S2*(SLP.2 ^-1);
         if j ne 2 then
            /* A := A*(((u*v^-1)^(j-2)*(u*v)^(j-2)*(u*v^-1)^(j-2) 
                    *(u*v)^(j-2)*u)^-1);
               swaps block 2 with block j
            */
	    SwapColumns(~A, 3, 2*j -1);
	    SwapColumns(~A, 4, 2*j);
            S2 := S2*(((SLP.4*SLP.5^-1)^(j-2)*
                     (SLP.4*SLP.5)^(j-2)*(SLP.4*SLP.5^-1)^(j-2)*
                     (SLP.4*SLP.5)^(j-2)*SLP.4)^-1);
         end if;
         BB := (1-A[1, 1])/A[1, 2];
         TT := GetBBTransvection(BB, SLP);
         // A := A*T;
         AddColumn(~A, BB, 2, 1);
         S2 := S2*TT;
      end if;
   end if;

assert A[1, 1] eq 1;
end procedure;

/* creating H. H is the subgroup of G that fixes the first basis
   element of the natural module. As this has a p-local subgroup, it
   affords a 1-dimensional submodule in the natural dimension.
*/

GetSpU := function (E, Q, d, qq) 
   q := #BaseRing(Q[1]);
   F := GF(q);
   w := PrimitiveElement(F); 
   M := KMatrixSpace(F, d, d);
   b := Basis(M);
   G := SL(d, qq);
   n := Degree(Q[1]);
   e := Degree(F);
   QQ := SpChosenElements(Sp(d, qq));

   if assigned E`Module then
      return E`Module;
   end if;

   CB := SymplecticCBM(Sp(d, qq));

   s := Q[1];
   v := Q[2];
   t := Q[3];
   delta := Q[4];
   u := Q[5];
   x := Q[6];

   HEQ := [s^v, v*u, u^v, t^v, delta^v, x, delta, x^v];
   if d eq 6 then
      HEQ := [s^v, u^v, t^v, delta^v, x, delta, x^v];
   end if;
   if d eq 4 then
      HEQ := [s^v, t^v, delta^v, delta, x^v];
   end if;
   if d eq 2 then
      HEQ := [delta, t^s];
   end if;

   HE := sub<GL(n, q)|HEQ>;
   VPH := GModule(HE);
   U := CompositionSeries(VPH)[1];

   V := VectorSpace(GF(q), n);
   U1 := sub<V|[V!VPH!U.i : i in [1..Dimension(U)]]>;
   /* Here U has been rewritten in vectors of length n but
      the module still has its original dimension
   */

   if d ne 2 then
      splodge1:= ((x^(v^2))^(u^s))^(v^-1);
   else
      splodge1:= t;
   end if;
   Remove(~HEQ, #HEQ);
   Append(~HEQ, splodge1);
   HE2 := sub<GL(n, q)| HEQ>;
   VPH2 := GModule(HE2);
   U := CompositionSeries(VPH2)[1];
   U2 := sub<V|[V!VPH2!U.i : i in [1..Dimension(U)]]>;

   E`Module := [U1, U2];
   return E`Module;
end function;

GetO := function(Q, d, qq)

   q := #BaseRing(Q[1]);
   F := GF(q);
   w := PrimitiveElement(GF(qq));
   t := Q[3];
   delta := Q[4];
   Z := IntegerRing();
   e := Factorization(qq)[1][2];

   FF := sub<F|w^2>;
   py := FF!w;
   
   /* py is now a polynomial in w^2 that is equal to w */
   
   O := Id(Parent(Q[1]));
   for i in [1..e] do
      O := O*(t^delta^-(i-1))^Z!Eltseq(py)[i];
   end for;

   return O;
end function;

/* we now create an elementary abelian p-group K. The generators of
   K consist of those elements with some power of the primitive
   element in the top row (excluding the first position), 1s down
   the leading diagonal and 0s everywhere else
*/

GetSpK := function(E, Q, d, qq) 
   q := #BaseRing(Q[1]);
   F := GF(q);
   w := PrimitiveElement(GF(qq)); 
   M := KMatrixSpace(GF(qq), d, d);
   b := Basis(M);
   G := SL(d, qq);
   n := Degree(Q[1]);
   e := Degree(F);
   QQ := SpChosenElements(Sp(d, qq));

   CB := SymplecticCBM(Sp(d, qq));

   if assigned E`PG1 then
      return E`PG1, E`PG2, E`PG3;
   end if;

   s := QQ[1];
   v := QQ[2];
   t := QQ[3];
   delta := QQ[4];
   u := QQ[5];
   x := QQ[6]^(QQ[2]^2);

   KQ := [];
   for j in [0..(e-1)] do
      Append(~KQ, x^(delta^j));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~KQ, (x^(delta^j))^((v*u)^i));
      end for;
   end for;
   for j in [0..(e-1)] do
      Append(~KQ, (x^(delta^j))^(s^u));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~KQ, (x^(delta^j))^((s^u)*(v*u)^i));
      end for;
   end for;
   Append(~KQ, Transpose(t));
   for j in [1..(e-1)] do
      temp := M!Transpose(t);
      temp[2, 1] := w^j;
      Append(~KQ, temp);
   end for;

   KQ := [Transpose (KQ[i]): i in [1..#KQ]];

   K := sub<SL(d, qq)|KQ>;

   S := [K.i : i in [1..Ngens(K)]];

   /* mapping K to the non-natural representation */
   s := Q[1];
   v := Q[2];
   t := Q[3];
   delta := Q[4];
   u := Q[5];
   x := (Q[6]^(Q[2]^2))^(Q[5]^Q[1]);

   kk := [];
   for j in [0..(e-1)] do
      Append(~kk, x^(delta^-j));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~kk, (x^(delta^-j))^((v*u)^i));
      end for;
   end for;
   for j in [0..(e-1)] do
      Append(~kk, (x^(delta^-j))^(s^u));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~kk, (x^(delta^-j))^((s^u)*(v*u)^i));
      end for;
   end for;

   O := GetO(Q, d, qq);

   for j in [1..e] do
      if IsOdd(j) then
         T := t^(delta^-((j-1) div 2));
         Append(~kk, T);
      else
         T := O^(delta^-((j-1) div 2));
         Append(~kk, T);
      end if;
   end for;

   KE := sub<GL(n, q)|[kk[i] : i in [1..#kk]]>;

   KQ := [Transpose (KQ[i]):  i in [1..#KQ]];

   K := sub<SL(d, qq)|[KQ[i] : i in [1..#KQ]]>;
   S1 := [K.i : i in [1..Ngens(K)]];

   s := Q[1];
   v := Q[2];
   t := (Q[3]^Q[1])^-1;
   delta := Q[4];
   u := Q[5];
   x := Q[6]^(Q[2]^2);

   kk2 := [];
   for j in [0..(e-1)] do
      Append(~kk2, x^(delta^j));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~kk2, (x^(delta^j))^((v*u)^i));
      end for;
   end for;
   for j in [0..(e-1)] do
      Append(~kk2, (x^(delta^j))^(s^u));
   end for;
   for i in [1..(d div 2) - 2] do
      for j in [0..(e-1)] do
         Append(~kk2, (x^(delta^j))^((s^u)*(v*u)^i));
      end for;
   end for;

   for j in [1..e] do
      if IsOdd(j) then
         T := t^(delta^((j-1) div 2));
         Append(~kk2, T);
      else
         T := ((O^Q[1])^-1)^(delta^((j-1) div 2));
         Append(~kk2, T);
      end if;
   end for;

   KE2 := sub<GL(n, q)|[kk2[i] : i in [1..#kk2]]>;

   E`PG1 := [KE, KE2];
   E`PG2 := kk;
   E`PG3 := [S, S1];
   return E`PG1, E`PG2, E`PG3;
end function;

/* Q is the set of generators of E - the alternative representation;
   g is the element that we need to find in terms of the generators,
   d is the dimension of the natural representation
   and qq is the size of the field of the natural representation
*/

intrinsic SpAltRepWordInGen(E:: GrpMat, Q:: SeqEnum, g:: GrpMatElt,
    d:: RngElt, q:: RngElt) -> BoolElt, GrpSLPElt
{E is a representation of Sp(d, q), Q is the image of standard generators
 of Sp(d, q) in E; write g, an element of E, as an SLP in Q}

   qq := q;
   q := #BaseRing(Q[1]);
   F := GF(q);
   w := PrimitiveElement(F); 
   M := KMatrixSpace(GF(qq), d, d);
   b := Basis(M);
   G := SL(d, qq);
   n := Degree(Q[1]);
   e := Degree(F);
   QQ := SpChosenElements(Sp(d, qq));

   CB := SymplecticCBM(Sp(d, qq));

   U := GetSpU(E, Q, d, qq);
   U1 := U[1];
   U2 := U[2];

   K, kk, S := GetSpK(E, Q, d, qq);
   KE := K[1];
   KE2 := K[2];
   S1 := S[2];
   S := S[1];

   W := U1^g;
   J1, J2, x, xslp := UnipotentStabiliser(KE, U1: ComputeBase := false);
   L1, L2, y, yslp := UnipotentStabiliser(KE, W:  ComputeBase := false);

   Ubar := U1;
   /* U^g*y*x^-1 eq U should be true. */

   /* This code permutes the columns of g until we get a non-zero
      entry in the (1, 1) position of the natural module.
   */

   vpower := 0;
   spower := 0;
   bool := (W^(y*x^-1) eq U1);
   temp := g;
   v := Q[2];
   s := Q[1];
   while bool eq false do
      g := g*v;
      vpower := vpower + 1;
      W := U1^g;
      J1, J2, x, xslp := UnipotentStabiliser(KE, U1:
         ComputeBase := false);
      L1, L2, y, yslp := UnipotentStabiliser(KE, W:ComputeBase
         := false);
      bool := (W^(y*x^-1) eq U1);
      if vpower gt d then
         vpower := 0;
         g := temp;
         break;
      end if;
   end while;
   while bool eq false do
      spower := 1;
      g := g*v*s;
      vpower := vpower + 1;
      W := U1^g;
      J1, J2, x, xslp := UnipotentStabiliser(KE, U1: ComputeBase := false);
      L1, L2, y, yslp := UnipotentStabiliser(KE, W: ComputeBase := false);
      bool := (W^(y*x^-1) eq U1);
      if bool eq false then g := g*(s^-1); end if;
      if vpower gt d then return false, _, _; end if;
   end while;

   /* We have now killed the top row of the preimage of g. We now do
      the same to the second row
   */

   h := g*y*x^-1;
   W := U2^h;
   J1, J2, x, xslp1 := UnipotentStabiliser(KE2, U2: ComputeBase := false);
   L1, L2, y, yslp1 := UnipotentStabiliser(KE2, W: ComputeBase := false);

   /* We check that J2 eq L2. We do not need to perform the vpower
      while loop above because we know that the top left hand corner of
      the pre-image of g cannot now be 0.
   */

   if J2 ne L2 then return false, _, _; end if;

   /* this has zeroes in the first two rows and columns in the
      natural rep (except the (1, 1) and (1, 2) places)
   */
   a := h*y*x^-1;

   t := QQ[3];
   delta := QQ[4];
   u := QQ[5];
   v := QQ[2];
   x := QQ[6]^(QQ[2]^2);
   s := QQ[1]^-1;
   KQ := [];
   Append(~KQ, Transpose(t));
   Append(~KQ, x^(s^u));
   Append(~KQ, x);
   for i in [1..(d div 2) - 2] do
      Append(~KQ, x^((s^u)*(v*u)^i));
      Append(~KQ, x^((v*u)^i));
   end for;

   KQ := [Transpose (KQ[i]): i in [1..#KQ]];

   t := Q[3];
   delta := Q[4];
   u := Q[5];
   v := Q[2];
   x := (Q[6]^(Q[2]^2))^(Q[5]^Q[1]);
   s := Q[1]^-1;
   kq := [];
   Append(~kq, t);
   Append(~kq, x^(s^u));
   Append(~kq, x);
   for i in [1..(d div 2) - 2] do
      Append(~kq, x^((s^u)*(v*u)^i));
      Append(~kq, x^((v*u)^i));
   end for;

   /* these all should be multiples of the generators of KE
      meaning you can solve the equation (x_1 .. x_d) = (y_1 .. y_d)A
      in the lower dimension, where A is the untouched d-1 * d-1
      portion of the matrix g */
   Y := [kq[i]^a: i in [1..#kq]];

   /* So Y[1], for example, is the image of a matrix whose second row
      is the top row of A. Hence it will be some linear combination
      of generators of KE.
   */

   /* we calculate what each Y[i] is in the natural representation */
   Z := [Evaluate(MatrixPGroupWordInGen(Y[i], KE: ComputeBase := false), S):
         i in [1..d - 1]];

   /* constructing the preimage of a */
   aa := M!b[1];
   for i in [1..d-1] do
      for j in [2..d] do
         aa := aa + Z[i][1, j] * b[d*i + j];
      end for;
   end for;

   bool := false;
   det := Determinant(aa);
   g := temp;
   p := Characteristic (F);
   P := PolynomialRing(GF(q));
   py := P.1^d - det;
   Scalars := <>;
   for i in [1..p-1] do
      for j in [0..e-1] do
         Append(~Scalars, ScalarMatrix(n, i)*w^j);
      end for;
   end for;
   Scalars := sub<GL(n, q) | [Scalars[i] : i in [1..#Scalars]]>;

   v := Q[2];
   s := Q[1];
   sq := Root(det, d); // may give wrong answer as multivalued.
   word := sq^-1 * aa * Evaluate(xslp1, S1) * Evaluate(yslp1^-1, S1)
           * Evaluate(xslp, S) * Evaluate(yslp^-1, S);
   flag, word := SymplecticWordInGen(Sp(d, GF(qq)), 
                                     GL(d, GF (qq)) ! word^(CB^-1));
   
   if (flag ne true) then
      _, J := SymplecticForm(Sp(d, GF(qq)));
      J := CB^-1*J*CB;
      j := Root((Transpose(aa)*J*aa)[1, 2], 2);
      aa := aa/j;
      sq := 1;
      py := P.1^d - 1;
      word := sq^-1 * aa * Evaluate(xslp1, S1) * Evaluate(yslp1^-1, S1)
         * Evaluate(xslp, S) * Evaluate(yslp^-1, S);
      flag, word := SymplecticWordInGen(Sp(d, GF(qq)), 
                                        GL(d, GF (qq)) ! word^(CB^-1));
      bool := Evaluate(word, Q) eq g * (v^-1)^-vpower * (s^-1)^-spower;
   end if;
   
   if Determinant(aa) ne 1 then
      while flag ne true do 
         sq := Root(det, d); // may give wrong answer as multivalued.
         word := sq^-1 * aa * Evaluate(xslp1, S1) * Evaluate(yslp1^-1, S1) 
                 * Evaluate(xslp, S) * Evaluate(yslp^-1, S);
         flag, word := SymplecticWordInGen(Sp(d, GF(qq)), 
                                           GL(d, GF (qq)) ! word^(CB^-1));
      end while;
   end if;

   first := Evaluate(word, Q);
   second := g * (v^-1)^-vpower * (s^-1)^-spower;
   bool := first eq second;
   scalar := first / second;

   if bool eq false then
      if not IsScalar(scalar) then
         bool := false;
      else
         roots := Roots(py);
         for j in [1..#roots] do
            word := roots[j, 1]^-1 * aa * Evaluate(xslp1, S1) *
            Evaluate(yslp1^-1, S1) * Evaluate(xslp, S) * Evaluate(yslp^-1, S);
            _, word := SymplecticWordInGen(G, GL(d, GF (qq)) ! word^(CB^-1));
            bool := Evaluate(word, Q) eq g * (v^-1)^-vpower * (s^-1)^-spower;
            if bool then scalar := Id(Parent(g)); break j; end if;
         end for;
      end if;
   end if;

   word := word * ((Parent(word).1)^-1)^spower * ((Parent(word).2)^-1)^vpower;

   if scalar eq Id(Parent(g)) then
      flag := Evaluate(word, Q) eq g;
   else
      flag := false;
   end if;

   return flag, word, scalar[1, 1];
end intrinsic;
