/*
input: subgroup <G> of GL(2,q)
output:
   <flag> = true if <G> preserves unique symmetric bilinear form
   <form> = symmetric form preserved by <G>
*/
SymmetricForm2 := function (G) 
     M := GModule (G);
     N := Dual (M);
     F := BaseRing (G);
     mat := KMatrixSpace (F, 2, 2);
     Ghom := sub < mat | Basis (AHom (M, N)) >;
     sym := sub < mat | [ [1,0,0,0], [0,1,1,0], [0,0,0,1] ] >; 
     Gsym := Ghom meet sym;
     if Dimension (Gsym) ne 1 then
//         InfoRecog (2, "<G> does not preserve a unique symmetric form");
         if #F in {3, 5} and #G in {1, 2} then 
            return true, MatrixAlgebra (F, 2)![0,1,1,0];
         end if;
         return false, _;
     else
         return true, MatrixAlgebra (BaseRing (G), 2)!Gsym.1;
     end if;
end function;

/*
input: any matrix group <G> and symmetric form <bil> preserved by <G>
output:
   <flag> = true if <G> preserves a quadratic form with associated bilinear form <bil>
   <form> = the quadratic form preserved, given in its usual form
*/
QuadraticFormOfBilinearForm := function (G, bil)

     d := Nrows (bil);

     if Characteristic (BaseRing (G)) eq 2 then
        X := Zero (KMatrixSpace (BaseRing (G), d, d * Ngens (G)));
        W := Zero (KMatrixSpace (BaseRing (G), 1, d * Ngens (G)));
        for i in [1..Ngens (G)] do
           g := G.i;
           for s in [1..d] do
           // modify column (i, s) of X
              for t in [1..d] do
                 if s eq t then
                    X[t][(i-1)*d+t] := g[t][t]^2 - 1;
                 else
                    X[t][(i-1)*d+s] := g[s][t]^2;
                 end if;
              end for;
              // modify entry (i, s) of W
              W[1][(i-1)*d+s] := &+[ g[s][t] * g[s][u] * bil[t][u] : 
                                  t in [1..d], u in [1..d] | u gt t];
           end for;
        end for;

        // test for a solution to the linear system
        flag, diag, ker := IsConsistent (X, W);
        if not flag then
//            InfoRecog (2, "<G> preserves no quadratic form");
           return false, _;
        end if;
        diag := diag[1];

     else
	diag := [ bil[i][i]/2 : i in [1..Nrows (bil)] ]; 
     end if; 

     // insert diagonal entries
     form := Zero (MatrixAlgebra (BaseRing (G), d));
     for s in [1..d] do
        form[s][s] := diag[s];
        for t in [s+1..d] do
	   form[s][t] := bil[s][t];
        end for;
     end for;
     
return true, form;
end function;

/*
input: subgroup <G> of GL (2, q)
output:
   <flag> = true if <G> preserves a unique quadratic form 
   <form> = the quadratic form preserved
    <bil> = the associated bilinear form
   <type> = the type of <form>  ... "orthogonalplus" or "orthogonalminus"
*/
OrthogonalForm2 := function (G) 
     flag, bil := SymmetricForm2 (G);
     if not flag then
        return false, _, _, _; 
     end if;
     flag, form := QuadraticFormOfBilinearForm (G, bil);
     if not flag then
        return false, _, _, _;
     end if;
     // next determine the type
     pol := Polynomial ([ form[1][1], form[1][2], form[2][2] ]);
     if #Roots (pol) eq 0 then
        type := "orthogonalminus";
     else
        type := "orthogonalplus";
     end if;
return true, form, bil, type;
end function;

